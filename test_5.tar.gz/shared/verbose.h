#ifndef LINFO2241_ARCH_PROJECT1_PART1_VERBOSE_H
#define LINFO2241_ARCH_PROJECT1_PART1_VERBOSE_H

#include <stdbool.h>

int verbose(const char * restrict, ...);
void setVerbose(bool);

#endif //LINFO2241_ARCH_PROJECT1_PART1_VERBOSE_H
