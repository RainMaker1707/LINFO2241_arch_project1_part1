#ifndef LINFO2241_ARCH_PROJECT1_PART1_CRYPT_TOOLS_H
#define LINFO2241_ARCH_PROJECT1_PART1_CRYPT_TOOLS_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>


void encrypt_file(int key_size, char* key, int file_size, char* file, char* encrypted_file);


#endif //LINFO2241_ARCH_PROJECT1_PART1_CRYPT_TOOLS_H
