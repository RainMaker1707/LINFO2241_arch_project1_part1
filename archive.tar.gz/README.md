# LINFO2241 Architecture project 1 part 1

### Project description
Client - router - server application, server should serve files, encrypted with a key given by the client.

### Makefile

`make server` compile the server executable, output: server.e\
`make client` compile the client executable, output: client.e\
`make server_run` compute server if not yet and run it\
`make client_run` compute client if not yet and run it\
`make clean` clean the repo by removing the library object and the compiled executables\

### Server

### Clients
